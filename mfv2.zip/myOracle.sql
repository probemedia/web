--update문을 사용힌 레코드 수정
update member3 set passwd='3579' where id='hongkd@aaa.com';

select * from member3;

--delete문을 사용한 레코드 삭제
delete from member3 where id='hongkd@aaa.com';

select * from member3;

delete from member3;

--alter문을 사용한 테이블구조 수정
alter table member3 
      modify(passwd varchar2(60));

select * from cols where table_name='MEMBER3';

select * from member3;

--board테이블 생성
create table board(
  num number not null primary key,
  writer varchar2(50) not null,
  subject varchar2(50) not null,
  passwd varchar2(60) not null,
  reg_date date not null,
  readcount number default 0,
  ref number not null,
  re_step number not null,
  re_level number not null,
  content clob not null,
  ip varchar2(30) not null
);

select * from cols where table_name='BOARD';

select * from board;

SELECT *
FROM (SELECT e.*, row_number() over (order by ref desc, re_step) 
              FROM board e)
WHERE num between 1 and 1;

SELECT *
FROM (SELECT e.*, row_number() over (order by ref desc, re_step) 
              FROM board e)
WHERE num between 1 and 3;

select 
    * 
from 
    board
where 
     rownum <= 3 
order by 
    ref desc, re_step;
    
--boardlist테이블 생성
create table boardlist(
  num number not null primary key,
  writer varchar2(50) not null,
  subject varchar2(50) not null,
  passwd varchar2(60) not null,
  reg_date date not null,
  content clob not null
);

insert into boardlist(num,writer,subject,passwd,reg_date,content)
  values(1,'관리자','가장 좋아하는 영화','1234',sysdate,'마블 시네마틱 유니버스. 세계관이 이어지는 점이 재미있다. 대 타노스 전을 기다림... 트랜스포머 시리즈. 로봇은 나에게 영원한 테마이다. 티셉디콘이여 영원하라...');
insert into boardlist(num,writer,subject,passwd,reg_date,content)
  values(2,'관리자','가장 좋아하는 게임','1234',sysdate,'스타크래프트. 이 방대한 우주관!!! . My life for Auir! 엔타로 제라툴 !! 워크래프트. 고대의 전쟁부터이어지는 판타지의 결정판. 록타르오가르!!');
insert into boardlist(num,writer,subject,passwd,reg_date,content)
  values(3,'관리자','가장 좋아하는 책','1234',sysdate,'무협지. 책만 읽어도 격공섭물과 허공답보를 할 수 있을 것 같다.');

select * from boardlist;