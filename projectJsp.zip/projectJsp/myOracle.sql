--전체 테이블 목록 확인 
--select * from user_tables;

select * from tabs;

--전체 테이블의 수 얻어내기
select count(*) from tabs;

--member라는 테이블이 있는지 확인하기. 테이블명은 대소문자가 구분되니 주의!
select count(*) from tabs where table_name='MEMBER';

--member테이브의 스키마구조 확인
select * from cols where table_name='MEMBER';

--member테이블 생성
create table member(
   id varchar2(12) not null primary key,
   passwd varchar2(12) not null,
   name varchar2(10) not null,
   reg_date date not null
 );

--member테이블에 insert문을 사용한 레코드 추가 및 확인
insert into member(id,passwd,name,reg_date)
  values('aaaa','1234','김개동',sysdate);
  
select * from member;

--member3테이블 생성
create table member3(
  id varchar2(50) not null primary key,
  passwd varchar2(16) not null,
  name varchar2(10) not null,
  reg_date date not null
);

select * from cols where table_name='MEMBER3';

--test_1테이블 생성
create table test_1(
  num_id number not null primary key,
  title varchar2(50) not null,
  content clob not null
);
--sequence생성
create sequence num_seq
increment by 1
start with 1;

select num_seq.CURRVAL from DUAL;

--sequence제거
drop sequence num_seq;
delete  from test_1;

--sequence필드를 가진 테이블의 레코드 추가 및 확인
insert into test_1 values(num_seq.nextval, 'test걍','내용');
select * from test_1;

--alter문을 사용한 테이블구조 수정
alter table member3 
      add(address varchar2(100) not null,
           tel varchar2(20) not null);

--member3테이블에 insert문을 사용한 레코드 추가 및 확인
insert into member3(id,passwd,name,reg_date,address,tel)
  values('kingdora@dragon.com','1234','김개동',sysdate,'서울시','010-1111-1111');
insert into member3(id,passwd,name,reg_date,address,tel)
  values('hongkd@aaa.com','1111','홍길동',sysdate,'경기도','010-2222-2222');  
  
select * from member3;

--update문을 사용힌 레코드 수정
update member3 set passwd='3579' where id='hongkd@aaa.com';

select * from member3;

--delete문을 사용한 레코드 삭제
delete from member3 where id='hongkd@aaa.com';

select * from member3;

delete from member3;

--alter문을 사용한 테이블구조 수정
alter table member3 
      modify(passwd varchar2(60));

select * from cols where table_name='MEMBER3';

select * from member3;

--board테이블 생성
create table board(
  num number not null primary key,
  writer varchar2(50) not null,
  subject varchar2(50) not null,
  passwd varchar2(60) not null,
  reg_date date not null,
  readcount number default 0,
  ref number not null,
  re_step number not null,
  re_level number not null,
  content clob not null,
  ip varchar2(30) not null
);

select * from cols where table_name='BOARD';

select * from board;

SELECT *
FROM (SELECT e.*, row_number() over (order by ref desc, re_step) 
              FROM board e)
WHERE num between 1 and 1;

SELECT *
FROM (SELECT e.*, row_number() over (order by ref desc, re_step) 
              FROM board e)
WHERE num between 1 and 3;

select 
    * 
from 
    board
where 
     rownum <= 3 
order by 
    ref desc, re_step;